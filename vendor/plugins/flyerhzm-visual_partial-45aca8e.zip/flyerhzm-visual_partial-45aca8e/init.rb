require 'visual_partial'
require 'render_partial'
