module VisualPartial
  mattr_accessor :display
end
